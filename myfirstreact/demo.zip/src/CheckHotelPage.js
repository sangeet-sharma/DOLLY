import React from 'react';
import SearchForm from './SearchForm';

function CheckHotelPage() {
  return (
    <div>
      
      <SearchForm />
    </div>
  );
}

export default CheckHotelPage;