//import Nav from './Nav';
//import Hero from './Hero';
//import Aboutus from './Aboutus';
//import Footer from './Footer';
import './Categorystyle.css';
//import Demo from './Demo';

function Category(){
    return(
     <>
     {/* <Nav/> */}
     {/* <Footer/> */}
     </>

    )
}
export default Category;