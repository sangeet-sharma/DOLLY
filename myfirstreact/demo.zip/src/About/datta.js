const people = [
    {
      id: 1,
      url: "https://watermark.lovepik.com/photo/20211203/large/lovepik-hotel-lobby-picture_501493440.jpg",
      
    },
    {
      id: 2,
      url: "https://png.pngtree.com/thumb_back/fw800/background/20210909/pngtree-wedding-daytime-wedding-hall-hall-hotel-interior-empty-mirror-photography-map-image_837460.jpg",
      
    },
    {
      id: 3,
      url: "https://cdn.pixabay.com/photo/2014/07/10/17/17/hotel-389256__340.jpg",
     
    },
    {
      id: 4,
      url: "https://c4.wallpaperflare.com/wallpaper/721/832/884/5-star-hotel-room-wallpaper-preview.jpg",
    
    },
    {
      id: 5,
      url: "https://images.pexels.com/photos/3659683/pexels-photo-3659683.jpeg?cs=srgb&dl=pexels-suhel-vba-3659683.jpg&fm=jpg",
    
    },
    {
      id: 6,
      url: "https://www.raffles.com/assets/0/72/1930/1931/1956/58e252d1-f16e-48a5-915b-49d2ebf35d73.jpg",
    
    },
    {
      id: 7,
      url: "https://assets.architecturaldigest.in/photos/60082f8cb3d78db39997cb98/master/w_1600%2Cc_limit/Asian-Paints-Swimming-Pool-Shangrila-Shard.jpg",
    
    },
    {
      id: 8,
      url: "https://i.pinimg.com/736x/d0/11/7c/d0117c41dab8b29897ebde4e85d9b5ff--top-hotels-best-hotels.jpg",
    
    },
  
  ];
  
  export default people;