import React, { useState } from 'react'
import {Link, useNavigate} from 'react-router-dom';
import axios from 'axios'
function Signup() {
  const [name,setName] = useState("")
  const [email,setEmail] = useState("")
  const [password,setPassword] = useState("")
  const navigate = useNavigate()


  const handleSubmit = (e)=>{
e.preventDefault()
axios.post("http://localhost:4000/signup",{name,email,password}).then(response=>{
  console.log(response)
  navigate("/login")
}).catch(err=>{
  console.log(err)
})
  }
  // const navigate=useNavigate()
  return (
    <div className='d-flex justify-content-center align-items-center bg-white vh-100'>
    <div className='bg-info p-3 rounded'>
        <h2 align="center">Sign-Up</h2>
    <form onSubmit={handleSubmit} action="">
    <div className='mb-3'>
              <label htmlFor="name"><strong>Name</strong></label>
              <input type="text" name='name'
               value={name} 
              onChange={(e)=>setName(e.target.value)} placeholder='Enter Name' className='form-control rounded-0'/>
          </div>
       <div className='mb-3'>
              <label htmlFor="email"><strong>Email</strong></label>
              <input type="email"
              name='email' value={email} 
              onChange={(e)=>setEmail(e.target.value)}
              placeholder='Enter Email' className='form-control rounded-0'/>
          </div>
          <div className='mb-3'>
              <label htmlFor="password"><strong>Password</strong></label>
              <input type="password" value={password} name='password'
               onChange={(e)=>setPassword(e.target.value)} placeholder='Enter Password' className='form-control rounded-0'/>
          </div>
          <button className='btn btn-secondary w-100 rounded-0' type='submit'><strong>Sign up</strong></button>
          <p>You are agree to our terms and policies</p>
          <Link to='/login'><button className='btn btn-default border w-100 bg-light rounded-0 text-decoation-none'>login</button></Link>
     
          </form>
          </div>
  </div>
  )
}

export default Signup;
