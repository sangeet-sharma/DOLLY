const contactConfig = {
    description:'this is contact page'
    };
    
    export{
    contactConfig
    };